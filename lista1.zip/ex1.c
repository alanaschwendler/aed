//Alana Schwendler - M2

#include <stdio.h>
#include <stdlib.h>

void leValores(int n, int *vet);

int main() {
	int i, n;
	int *vet;

	printf("Tamanho do vetor: ");
	scanf("%d", &n);

	vet = malloc(sizeof(int)*n); //aloca o tamanho de um inteiro * tamanho
	
	leValores(n, vet);

	vet = &vet[0];

	for(i = 0; i < n; i++) {
		printf("Valor: %d \n", *vet);
		vet++; //anda uma posição de inteiro
	}

	free(vet);
	return 0;
}

void leValores(int n, int *vet) {
	int i;

	for(i = 0; i < n; i++) {
		printf("Valor: ");	
		scanf("%d", vet); //guarda o valor no vetor de valores
		vet++; //anda uma posição de inteiro
	}
}