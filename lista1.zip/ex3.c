//Alana Schwendler - M2

#include <stdio.h>
#include <stdlib.h>

int main() {
	int i, l, c;
	int **mat; //ponteiro pra matriz

	printf("Linhas: ");
	scanf("%d", &l);
	
	printf("Colunas: ");
	scanf("%d", &c);

	mat = (int **) malloc(sizeof(int) * m);

	for(i = 0; i < m; i++) {
		mat = (int **) malloc(sizeof(int) * n);
	}

	return 0;
}

/*
3) Construa um programa (main) que aloque em tempo de execução (dinamicamente)
uma matriz de ordem m x n (linha por coluna), usando 1+m chamadas a função malloc.
Agora, aproveite este programa para construir uma função que recebendo os
parametros m e n aloque uma matriz de ordem m x n e retorne um ponteiro para esta
matriz alocada. Crie ainda uma função para liberar a área de memória alocada pela
matriz. Finalmente, crie um novo programa (main) que teste/use as duas funções
criadas acima.
*/