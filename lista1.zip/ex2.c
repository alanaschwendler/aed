//Alana Schwendler - M2

#include <stdio.h>
#include <stdlib.h>

int * criaVetor(int n);
void leValores(int n, int *vet);
void imprime(int n, int *vet);
void libera(int *vet);

int main() { //função principal
	int n;
	int *v;

	printf("Tamanho do vetor: ");
	scanf("%d", &n);

	v = criaVetor(n);
	leValores(n, v);
	imprime(n, v);
	libera(v);

	return 0;
}

int * criaVetor(int n) {
	int *vet;
	vet = malloc(sizeof(int)*n); //aloca o tamanho de um inteiro * tamanho
	return vet;
}

void leValores(int n, int *vet) {
	int i;

	for(i = 0; i < n; i++) {
		printf("Valor: ");	
		scanf("%d", vet); //guarda o valor no vetor de valores
		vet = (int *)(vet + sizeof(int)); //anda uma posição de inteiro
	}
}

void imprime(int n, int *vet) {
	int i;
	for(i = 0; i < n; i++) {
		printf("Valor: %d \n", *vet);
		vet = (int *)(vet + sizeof(int)); //anda uma posição de inteiro
	}
}

void libera(int *vet) {
	free(vet);
}